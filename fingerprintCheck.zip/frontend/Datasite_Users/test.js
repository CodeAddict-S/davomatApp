let order = { "by": "type_user", "asc": true }
console.log('abc'>'cba');

let items_table = [
    {
        "type_user": "cba"
    },
    {
        "type_user": "abc"
    }
]
let sort = () => {
    let is_a_bigger_than_b = (itemA, itemB) => {
        if(itemA[order['by']]>itemB[order['by']]){
            return true
        }
        return false
    };
    let is_sorted = (arr) => {
        for(let index = 0; index < arr.length; index++){
            if(index < arr.length-1){
                if(is_a_bigger_than_b(arr[index], arr[index+1])){
                    return false 
                }
            }
        }
        return true
    }
    // while(!is_sorted(items_table)){
    //     for(let index = 0; index < items_table.length; index++){
    //         if(index < items_table.length-1){
    //             if(is_a_bigger_than_b(items_table[index], items_table[index+1])){
    //                 let saved_item_a = items_table[index]
    //                 items_table[index] = items_table[index+1]
    //                 items_table[index+1] = saved_item_a
    //             }
    //         }
    //     }
    // }
    console.log(is_sorted(items_table));
    
}

sort()

if(!order['asc']){
    items_table.reverse()
}

console.log(items_table)